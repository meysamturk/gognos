<?php

$conn = mysqli_connect('localhost','sql_gognos_com','d0f49c7223be2','sql_gognos_com') or die('connection failed');

?>