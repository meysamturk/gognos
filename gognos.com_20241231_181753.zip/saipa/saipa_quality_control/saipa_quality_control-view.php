<?php
    require 'config.php';
?>
<!doctype html>
<html lang="fa" dir="rtl">
  <head>
             <style>
                    @import url('https://fonts.googleapis.com/css2?family=Beiruti:wght@200..900&display=swap');
                    #div1{
                    font-family: "Beiruti", sans-serif;
                        }
              </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="../assets/Gognos_icon.png" />
    <!--  Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>نمایش جزئیات</title>
</head>
<body id="div1">

    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>نمایش جزئیات
                            <a href="index.php" class="btn btn-danger float-start">بازگشت</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            
                        
                         $student_id = mysqli_real_escape_string($conn, $_GET['id']);
                         $query = "SELECT * FROM `saipa_quality_control` WHERE id='$student_id' ";
                         $query_run = mysqli_query($conn, $query);
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $student = mysqli_fetch_array($query_run);
                                ?>
                                

                                <div class="mb-3">
                                        <label>نام</label>
                                        <p class="form-control">
                                            <?=$student['name'];?> 
               </p>                   
              </div>
                                    <div class="mb-3">
                                        <label>شماره پرسنل</label>
                                        <p class="form-control">
                                            <?=$student['user_number'];?>
       </p>                           
      </div>
                                    <div class="mb-3">
                                    <label>تاریخ</label>
                                       <<p class="form-control">
                                        <?=$student['date'];?>     
                                       </p>                       
           </div>
                                    <div class="mb-3">
                                    <label>شماره قطعه</label>
                                        <p class="form-control">
                                            <?=$student['block_number'];?>
      </p>                            
      </div>
                                    <div class="mb-3">
                                    <label>شیف کاری</label>
                                        <p class="form-control">
                                            <?=$student['work_shift'];?>
        </p>                          
      </div>
                                    <div class="mb-3">
                                    <label>اندازه:39</label>
                                       <p class="form-control">
                                        <?=$student['num39'];?>
               </p>                    
               </div>
                                    <div class="mb-3">
                                    <label>اندازه:59</label>
                                        <p class="form-control">
                                            <?=$student['num59'];?>           
                                             </p>                 
                                    </div>
                                    <div class="mb-3">
                                    <label>اندازه:185</label>
                                        <p class="form-control">
                                            <?=$student['num185'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:253</label>
                                        <p class="form-control">
                                            <?=$student['num253'];?>
              </p>                   
              </div>
                                    <div class="mb-3">
                                    <label>اندازه:217</label>
                                        <p class="form-control">
                                            <?=$student['num217'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:28</label>
                                        <p class="form-control">
                                            <?=$student['num28'];?>      
         </p>                           
         </div>
                                    <div class="mb-3">
                                    <label>اندازه:17 مقابل فیلتر</label>
                                        "<p class="form-control">
                                            <?=$student['num17f'];?>              
                                         </p>                  
                                    </div>
                                    <div class="mb-3">
                                    <label>اندازه:15مقابل فیلتر</label>
                                        <p class="form-control">
                                            <?=$student['num15mf'];?>
             </p>                      
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:15 فیلتر</label>
                                        <p class="form-control">
                                            <?=$student['num15f'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:17فیلتر</label>
                                        <p class="form-control">
                                            <?=$student['num17f'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:25مقابل فیلتر</label>
                                        <p class="form-control">
                                            <?=$student['num25mf'];?>
             </p>                       
            </div>
                                    <div class="mb-3">
                                    <label>اندازه:25 فیلتر</label>
                                        <p class="form-control">
                                            <?=$student['num25f'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:123</label>
                                        <p class="form-control">
                                            <?=$student['num123'];?>
              </p>                    
             </div>
                                    <div class="mb-3">
                                    <label>اندازه:168</label>
                                        <p class="form-control">
                                            <?=$student['num168'];?>
              </p>                     
            </div>
                                <?php
                            }
                            else
                            {
                                echo "<h4>مورد یافت شد</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
