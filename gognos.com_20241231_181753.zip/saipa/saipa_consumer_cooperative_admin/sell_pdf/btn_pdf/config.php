<?php

$conn = mysqli_connect('localhost','root','','saipa_db') or die('connection failed');

?>